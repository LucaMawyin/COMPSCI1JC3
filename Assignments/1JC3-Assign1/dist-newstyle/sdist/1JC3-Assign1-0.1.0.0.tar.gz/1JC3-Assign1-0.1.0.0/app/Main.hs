{-# LANGUAGE ExistentialQuantification #-}
module Main where

import qualified Assign_1 as A1

-- | Main Program
main :: IO ()
main = putStrLn "1JC3-Assign1 compiled successfully"
